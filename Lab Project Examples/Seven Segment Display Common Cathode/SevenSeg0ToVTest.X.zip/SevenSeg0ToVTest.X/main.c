/*
 created by Douglas Athenosy
 1/3/19
 for CDA3331C
 This project is an extention to project #5 pg 55 of Lucio Di Jasio's "In 10 Lines Of code"
 This project displays four different current levels across 4 7-seg Displays. 
 The digit that is displayed on the 7-seg displays is controlled by the potentiometer
 This is for a common cathode display
 * 
 * for a common cathode current flows from the common point Your A1-A4 to the SEGments Seg_A-Seg_G
 * 
 * NOTE the boards provided have resistors inline these resistors are there to protect your equipment and keep the genie inside. 
 * However they do make it quite difficult to see the difference in current level over the different digits
 */

#include "mcc_generated_files/mcc.h"
#define LIMIT_NONE 0X00
#define LIMIT_10mA 0X80
#define LIMIT_5mA  0X81
#define LIMIT_2mA  0X82
#define LIMIT_1mA  0X83
uint8_t matrix[]={//Matrix that translates needed digit to a binary string to control which of the LEDs in the 7 segment are on and off
  //a  b  c  d  e  f  g
    1, 1, 1, 1, 1, 1, 0, //1
    0, 1, 1, 0, 0, 0, 0,
    1, 1, 0, 1, 1, 0, 1, //0
    1, 1, 1, 1, 0, 0, 1, 
    0, 1, 1, 0, 0, 1, 1, //4
    1, 0, 1, 1, 0, 1, 1, 
    1, 0, 1, 1, 1, 1, 1, //6
    1, 1, 1, 0, 0, 0, 0, 
    1, 1, 1, 1, 1, 1, 1, //8
    1, 1, 1, 1, 0, 1, 1, 
    1, 1, 1, 0, 1, 1, 1, //a
    0, 0, 1, 1, 1, 1, 1, 
    0, 0, 0, 1, 1, 0, 1, //c
    0, 1, 1, 1, 1, 0, 1, 
    1, 0, 0, 1, 1, 1, 1, //e
    1, 0, 0, 0, 1, 1, 1, //the Below code had been added to include G-Z to the seven segment display matrix
    1, 0, 1, 1, 1, 1, 0, //g
    0, 1, 1, 0, 1, 1, 1,
    0, 0, 0, 0, 1, 1, 0, //i
    0, 1, 1, 1, 1, 0, 0, 
    1, 0, 1, 0, 1, 1, 1, //K
    0, 0, 0, 1, 1, 1, 0, 
    1, 1, 0, 1, 0, 1, 0, //m
    0, 0, 1, 0, 1, 0, 1,
    0, 0, 1, 1, 1, 0, 1, //o
    1, 1, 0, 0, 1, 1, 1, 
    1, 1, 1, 0, 0, 1, 1, //q 
    0, 0, 0, 0, 1, 0, 1, 
    1, 0, 1, 1, 0, 1, 1, //s
    0, 0, 0, 1, 1, 1, 1, 
    0, 0, 1, 1, 1, 0, 0, //u
    0, 1, 0, 1, 0, 1, 0, 
    0, 1, 1, 1, 1, 1, 1, //w
    1, 0, 0, 1, 0, 0, 1, 
    0, 1, 1, 1, 0, 1, 1, //y
    1, 1, 0, 1, 1, 0, 1, 

};
void digitShow(uint8_t value)
{// goes to the required value location in the matrix then runs through the whole length of the 7 segment display.
    //NOTE this code has been changed for common cathode the origanal code was ~*p++; 
    //the '~' is bitwise NOT in this instance it made all highs we had in the matrix low and the lows high this allowed for common anode to work
    uint8_t *p=&matrix[value*7];
    SEG_A_LAT = *p++;
    SEG_B_LAT = *p++;
    SEG_C_LAT = *p++;
    SEG_D_LAT = *p++;
    SEG_E_LAT = *p++;
    SEG_F_LAT = *p++;
    SEG_G_LAT = *p++;
    
}

void main(void)
{
    uint8_t digit;
    // initialize the device
    SYSTEM_Initialize();
    //NOTE This was changed from CCDNC and CCDNB for use in the common cathode What each value controls is gone over in the book "In Ten Lines of Code" on pg 59-60
    CCDPC |= 0b01001100;//Enables constant current for pin RC6(SEG_F) RC3(SEG_B) and RC2(SEG_A)
    CCDPB |= 0b00011111;//Enables constant current for pin RB4(SEG_G) RB3(SEG_C) RB2(SEG_DP) RB1(SEG_D) and RB0(SEG_E)
    
    A1_SetHigh();//turns off all the displays
    A2_SetHigh();
    A3_SetHigh();
    A4_SetHigh();
    SEG_DP_LAT = 0;
    while (1)
    {
 
        digit=(ADCC_GetSingleConversion(POT)>>5)+4; //change the +4 for different ranges +4 range 4-Z
        A4_SetHigh();//turns off 4th digit            Note this code has been changed for a common cathode there for setting A#High turns off that digit and setting A#Low turns on that digit.
        A1_SetLow();//turns on 1st digit
        CCDCON=LIMIT_2mA;//currentlimit
        digitShow(digit);
        __delay_ms(5);
        
        A1_SetHigh();//turns off 1st digit
        A2_SetLow();//turns on 2nd digit
        CCDCON=LIMIT_5mA;//currentlimit
        digitShow(digit);
        __delay_ms(5);
                
        A2_SetHigh();//turns off second digit
        A3_SetLow();//turns on 3rd digit
        CCDCON=LIMIT_10mA;//currentlimit
        digitShow(digit);
        __delay_ms(5);
        
        A3_SetHigh();//turns off 3rd digit
        A4_SetLow();//turns on 4th digit
        CCDCON=LIMIT_NONE;//currentlimit
        digitShow(digit);
        __delay_ms(5);
    }
}
/**
 End of File
*/