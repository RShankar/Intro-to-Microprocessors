/*
 * Made by Douglas Athenosy
 * For FAU CDA3331C
 * Date: 1-14-19
 * 
 * This is an extention of Lucio Di Jasio's "In 10 Lines of code" project 9 pg 85
 * This extention is for the 4-pin ping HC-SR04 sensor instead of a 3 pin  
 * VCC=5v
 * Echo=RC5
 * Trig=RC6
 * 
 * This program measures distance in both CM and Inches then prints them to a serial reader (cool term)
 * at a baudrate of 2400
 */

#include "mcc_generated_files/mcc.h"

/*
                         Main application
 */
void main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    TRIG_SetLow();//set trigger low to being pulse
    

    while (1)
    {
        
        TRIG_SetHigh();// Sends trigger pulse
        __delay_us(5);
        TRIG_SetLow();
        
        TMR1GIF=0;//resets timer
        TMR1_WriteTimer(0);
        TMR1_StartSinglePulseAcquisition();
        while(!TMR1GIF);// waits for return pulse to end
        printf("Distance = %f inches\n", TMR1_ReadTimer()/296.0); //math for inches
        printf("Distance = %f cm\n", TMR1_ReadTimer()/116.0);//math for cm
        
        __delay_ms(500);//rate of read
        
    }
}
/**
 End of File
*/