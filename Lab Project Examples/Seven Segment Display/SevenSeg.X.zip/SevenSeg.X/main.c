/*
 created by Douglas Athenosy
 1/3/19
 for CDA3331C
 This project is an extention to project #5 pg 55 of Lucio Di Jasio's "In 10 Lines Of code"
 This project displays four different current levels across 4 7-seg Displays. 
 The digit that is displayed on the 7-seg displays is controlled by the potentiometer
 There is a commented out initial test in the code which displays '1' across all displays
 */

#include "mcc_generated_files/mcc.h"
#define LIMIT_NONE 0X00
#define LIMIT_10mA 0X80
#define LIMIT_5mA  0X81
#define LIMIT_2mA  0X82
#define LIMIT_1mA  0X83
uint8_t matrix[]={//Matrix that translates needed digit to a binary string to control which of the LEDs in the 7 segment are on and off
  //a  b  c  d  e  f  g
    1, 1, 1, 1, 1, 1, 0, //0
    0, 1, 1, 0, 0, 0, 0,
    1, 1, 0, 1, 1, 0, 1, //2
    1, 1, 1, 1, 0, 0, 1, 
    0, 1, 1, 0, 0, 1, 1, //4
    1, 0, 1, 1, 0, 1, 1, 
    1, 0, 1, 1, 1, 1, 1, //6
    1, 1, 1, 0, 0, 0, 0, 
    1, 1, 1, 1, 1, 1, 1, //8
    1, 1, 1, 1, 0, 1, 1, 
    1, 1, 1, 0, 1, 1, 1, //a
    0, 0, 1, 1, 1, 1, 1, 
    0, 0, 0, 1, 1, 0, 1, //c
    0, 1, 1, 1, 1, 0, 1, 
    1, 0, 0, 1, 1, 1, 1, //e
    1, 0, 0, 0, 1, 1, 1, 
};
void digitShow(uint8_t value)
{// goes to the required value location in the matrix then runs through the whole length of the 7 segment display.
    uint8_t *p=&matrix[value*7];
    SEG_A_LAT = ~*p++;
    SEG_B_LAT = ~*p++;
    SEG_C_LAT = ~*p++;
    SEG_D_LAT = ~*p++;
    SEG_E_LAT = ~*p++;
    SEG_F_LAT = ~*p++;
    SEG_G_LAT = ~*p++;
    
}
/*
                         Main application
 */
void main(void)
{
    uint8_t digit;
    // initialize the device
    SYSTEM_Initialize();
    CCDNC |= 0b01001100;//Enables constant current for pin RC6(SEG_F) RC3(SEG_B) and RC2(SEG_A)
    CCDNB |= 0b00011111;//Enables constant current for pin RB4(SEG_G) RB3(SEG_C) RB2(SEG_DP) RB1(SEG_D) and RB0(SEG_E)
    A1_SetLow();//turns off all the displays
    A2_SetLow();
    A3_SetLow();
    A4_SetLow();
    //SEG_B_SetLow();//used for initial test
    //SEG_C_SetLow();//used for initial test
    while (1)
    {
        /*
        //initial test
        A4_SetLow();//turns off 4th digit
        A1_SetHigh();//turns on 1st digit
        CCDCON=LIMIT_2mA;//currentlimit
        __delay_ms(5);
        
        A1_SetLow();//turns off 1st digit
        A2_SetHigh();//turns on 2nd digit
        CCDCON=LIMIT_5mA;//currentlimit
        __delay_ms(5);
        
        A2_SetLow();//turns off second digit
        A3_SetHigh();//turns on 3rd digit
        CCDCON=LIMIT_10mA;//currentlimit
        __delay_ms(5);
        
        A3_SetLow();//turns off 3rd digit
        A4_SetHigh();//turns on 4th digit
        CCDCON=LIMIT_NONE;//currentlimit
        __delay_ms(5);
        */
        digit=(ADCC_GetSingleConversion(POT)>>6);
        A4_SetLow();//turns off 4th digit
        A1_SetHigh();//turns on 1st digit
        CCDCON=LIMIT_2mA;//currentlimit
        digitShow(digit);
        __delay_ms(5);
        
        A1_SetLow();//turns off 1st digit
        A2_SetHigh();//turns on 2nd digit
        CCDCON=LIMIT_5mA;//currentlimit
        digitShow(digit);
        __delay_ms(5);
                
        A2_SetLow();//turns off second digit
        A3_SetHigh();//turns on 3rd digit
        CCDCON=LIMIT_10mA;//currentlimit
        digitShow(digit);
        __delay_ms(5);
        
        A3_SetLow();//turns off 3rd digit
        A4_SetHigh();//turns on 4th digit
        CCDCON=LIMIT_NONE;//currentlimit
        digitShow(digit);
        __delay_ms(5);
    }
}
/**
 End of File
*/