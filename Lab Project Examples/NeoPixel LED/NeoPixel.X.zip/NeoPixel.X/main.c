/*
 Douglas Athenosy
 1/8/19
 NeoPixel color changing LED
 This code extends on lucio Di Jasio's project #12 in his book "In 10 lines of code"
 the extention changes the code from an array of LEDs to changing the color on one LED
 
 The Pin used to drive this is RB5
 The Pic16F18855 outputs 3.3v on the IOPins so you must power your pixel off the 3.3V pin NOT the 5v Pin
 */

#include "mcc_generated_files/mcc.h"

void NeoPixel_Stream(uint8_t *p, uint8_t count) 
{   // sends count x GRB data packets (24-bit each)
    uint8_t bitCount, data;
    while (count--) {
        bitCount = 24;
        do {
            if ((bitCount & 7) == 0) 
                data = *p++;    
            SSP1BUF = ((data & 0x80)) ? 0xFE : 0xC0;  // WS2812B 900ns - 350ns           
            data <<= 1;
        } while (--bitCount);
        __delay_ms(500); // allows for color changing on a single pixel comment out if you are looking to use an array
    } 
}

void main(void)
{
    SYSTEM_Initialize();
    //                 R G B triplets This could be GRB depending on the neoPixel
    //0xFF is the max value that can be used below
    uint8_t color[] = {0x8, 0, 0,    0, 0x8, 0,    0, 0, 0x8,    0x8, 0x8, 0x8};   
    uint8_t pointer=0;
    while (1)
    {
        NeoPixel_Stream(color, sizeof(color)/3);
        //__delay_ms(250); //Allows for an array of neopixels to run
    }
}
