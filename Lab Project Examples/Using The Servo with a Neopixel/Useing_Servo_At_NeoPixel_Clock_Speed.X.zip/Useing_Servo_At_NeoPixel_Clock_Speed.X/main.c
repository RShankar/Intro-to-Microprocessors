

#include "mcc_generated_files/mcc.h"

void NeoPixel_Stream(uint8_t *p, uint8_t count) 
{   // sends count x GRB data packets (24-bit each)
    uint8_t bitCount, data;
    while (count--) {
        bitCount = 24;
        do {
            if ((bitCount & 7) == 0) 
                data = *p++;    
            SSP1BUF = ((data & 0x80)) ? 0xFE : 0xC0;  // WS2812B 900ns - 350ns           
            data <<= 1;
        } while (--bitCount);
        
    } 
}
void main(void)
{
    // initialize the device
    SYSTEM_Initialize();

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    //INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();

    uint8_t color1[]={0xFF,0x00,0x00};
    uint8_t color2[]={0x00,0xFF,0x00};
    while (1)
    {
        PWM7_LoadDutyValue(100);
        NeoPixel_Stream(color1,1);
        __delay_ms(1000);
        PWM7_LoadDutyValue(499);
        NeoPixel_Stream(color2,1);
        __delay_ms(1000);
        
    }
}
/**
 End of File
*/